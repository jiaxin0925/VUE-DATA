<template>
    <div>
        this is  index page
    </div>
</template>

<script>
    export default {
        name: "",
		data(){
			return {
			}
		}
    }
</script>

<style>

</style>