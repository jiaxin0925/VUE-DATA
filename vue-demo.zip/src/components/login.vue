<template>
    <div>
        this is login page
    </div>
</template>

<script>
    export default {
        name: "",
		data(){
			return {
			}
		}
    }
</script>

<style>

</style>