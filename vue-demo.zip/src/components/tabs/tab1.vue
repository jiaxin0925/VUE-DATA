<template>
    <div>
        this  is tab1
    </div>
</template>

<script>
    export default {
        name: "",
		data(){
			return {
			}
		}
    }
</script>

<style>

</style>