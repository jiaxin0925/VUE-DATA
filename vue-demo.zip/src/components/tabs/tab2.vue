<template>
    <div>
        this  is tab2
    </div>
</template>

<script>
    export default {
        name: "",
		data(){
			return {
			}
		}
    }
</script>

<style>

</style>