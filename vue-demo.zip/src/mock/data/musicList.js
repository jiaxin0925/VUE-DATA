export default [{
    musicId: 1,
    name: "3ar",
    author: "末鹿",
    url: "static/media/3ar.mp3"
  },
  {
    musicId: 2,
    name: "病变 - Cubi",
    author: "BINGBIAN",
    url: "static/media/bingbian.mp3"
  },
  {
    musicId: 3,
    name: "CE FRUMOASA E IUBIREA",
    author: "Giulia",
    url: "static/media/CE FRUMOASA E IUBIREA.mp3"
  }
]
