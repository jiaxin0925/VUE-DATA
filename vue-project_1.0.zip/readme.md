# 学生管理平台

# 登陆
	用户名   验证长度12个字符   不为空  必填项
	密码     验证长度18个字符   不为空  必填项

	1、保存token到本地

# 注册

	用户名   验证长度12个字符   不为空  必填项
	密码     验证长度18个字符   不为空  必填项
	确定密码
	手机号
	随机数

	1、保存数据库
	2、自动登陆 并且跳转首页

# 首页

	显示图书产品信息
	收藏、购买

# 购物车页面
	

# 学生FM
	音乐列表
	点击播放



# VueRouter

1、引入vue vue-router
2、vue.use(vueRouter);
3、创建vueRouter实例，抛出
let router = new vueRouter({
	routes:[
		{
			//路由路径
			path:"",
			//路由名称
			name:"",
			//理由模板
			component:""
		}
	]
})
4、new Vue()  注入router