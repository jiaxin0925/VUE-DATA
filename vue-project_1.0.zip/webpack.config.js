let fs = require("fs");
let url = require("url");
let querystring = require("querystring");
let path = require("path");
let webpack = require("webpack");
let ExtractTextPlugin = require("extract-text-webpack-plugin");
let HtmlWebpackPlugin = require("html-webpack-plugin");

let getData = function(req, res, filepath) {
    console.log(filepath);
    fs.exists(filepath, function(exist) {
        if (!exist) return;
        fs.readFile(filepath, function(err, data) {
            if (err) return console.error(err);
            console.log(data);
            res.writeHead(200, {
                "Content-Type": "text/json;charset=utf8",
                "Access-Control-Allow-Origin": "*",
            });
            res.end(data);
        });
    });
}

let getJson = function(req, res, filepath, oQuery) {
    fs.exists(filepath, function(exist) {
        if (!exist) return;
        fs.readFile(filepath, function(err, data) {
            if (err) return console.error(err);
            res.writeHead(200, {
                "Content-Type": "text/json;charset=utf8",
                "Access-Control-Allow-Origin": "*",
            });
            let result = JSON.parse(data);
            result.map((item, index) => {
                if (item.name == oQuery.name) {
                    res.end(JSON.stringify(item));
                } else {
                    res.end("error");
                }
            })
        });
    });
}

module.exports = {
    entry: {
        "app": path.join(__dirname, "src/app.js")
    },
    output: {
        path: path.join(__dirname, "dist"),
        filename: "[name].js",
        chunkFilename: '[name].[chunkhash:3].min.js'
    },
    module: {
        rules: [{
                test: /\.js$/,
                loader: "babel-loader",
                exclude: "/node_modules/"

            }, {
                test: /\.vue$/,
                loader: "vue-loader"
            }, {
                test: /\.css$/,
                use: ExtractTextPlugin.extract({
                    fallback: "style-loader",
                    use: ["vue-style-loader", "css-loader"]
                })
            },
            {
                test: /\.(png|jpg|gif)$/,
                loader: 'file-loader',
                options: {
                    name: '[name].[ext]?[hash]'
                }
            }, {
                test: /\.(eot|svg|ttf|woff|woff2|otf)/,
                use: "url-loader?limit=50000&name=[path][name].[ext]"
            }
        ]
    },
    resolve: {
        extensions: ['.js', '.vue', '.json', '.css'],
        alias: {
            '@': path.resolve(__dirname, 'src'),
            'vue$': 'vue/dist/vue.esm.js',
        },
        modules: [path.resolve(__dirname, 'src'), 'node_modules']
    },
    devServer: {
        host: "localhost",
        port: 8080,
        contentBase: ".",
        historyApiFallback: true
        // proxy:{
        //     "/api":{
        //         target:"http://localhost:8090"
        //     }
        // }
        // setup(app) {
        //     app.get("/data", (req, res) => {
        //         let oUrl = url.parse(req.url);
        //         let pathname = oUrl.pathname;
        //         let oQuery = querystring.parse(oUrl.query);
        //         let filepath = path.join(__dirname, "data", pathname + ".json");
        //         if (oQuery.name == undefined) {
        //             getData(req, res, filepath);
        //         } else {
        //             getJson(req, res, filepath, oQuery);
        //         }

        //     })
        // }
    },
    plugins: [
        new ExtractTextPlugin('css/[name].css'),
        new webpack.optimize.CommonsChunkPlugin({
            name: 'commons',
            filename: 'commons.js'
        }),
        new webpack.HotModuleReplacementPlugin(),
        new HtmlWebpackPlugin({
            filename: "index.html",
            template: "./index.html"
        })
    ]
}