let dataArray = {
    dalu: [{
            "id": 1,
            "image": "./src/images/musicbg.gif",
            "name": "80000（prod.by DROYC Autotune版) - PRC",
            "url": "./src/media/80000.mp3"
        },
        {
            "id": 2,
            "image": "./src/images/musicbg.gif",
            "name": "衡山路（2016现场版） - 小海",
            "url": "./src/media/hengshanlu.mp3"
        },
        {
            "id": 3,
            "image": "./src/images/musicbg.gif",
            "name": "Heartbeat (Nightcore) [PØRPEL Remix] - PØRPEL",
            "url": "./src/media/heartbeat.mp3"
        }
    ],
    tangtai: [{
            "id": 1,
            "image": "./src/images/musicbg.gif",
            "name": "80000（prod.by DROYC Autotune版) - PRC2",
            "url": "./src/media/80000.mp3"
        },
        {
            "id": 2,
            "image": "./src/images/musicbg.gif",
            "name": "衡山路（2016现场版） - 小海2",
            "url": "./src/media/hengshanlu.mp3"
        },
        {
            "id": 3,
            "image": "./src/images/musicbg.gif",
            "name": "Heartbeat (Nightcore) [PØRPEL Remix] - PØRPEL2",
            "url": "./src/media/heartbeat.mp3"
        }
    ]
}
export default dataArray;