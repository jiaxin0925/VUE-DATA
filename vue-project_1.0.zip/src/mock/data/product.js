let dataArray = [{
        "id": 1,
        "name": "劳力士(ROLEX)蚝式恒动日志型机械男表116300蓝",
        "info": "劳力士（Rolex）是瑞士著名的手表制造商，前身为Wilsdorf and Davis（W&D）公司，由德国人汉斯·威斯多夫（Hans Wilsdof）与英国人戴维斯（Alfred Davis）于1905年在伦敦合伙经营。1908年由汉斯·威斯多夫在瑞士的拉夏德芬（La Chaux-de-Fonds）注册更名为ROLEX。经过一个世纪的发展，总部设在日内瓦的劳力士公司已拥有19个分公司，在世界主要的大都市有24个规模颇大的服务中心，年产手表45万只左右，成为市场占有量甚大的名牌手表之一。",
        "price": 55955,
        "image": "./src/images/img1.jpg",
        "count": 1,
        "isCheck": true
    },
    {
        "id": 2,
        "name": "卡地亚(Cartier)手表 伦敦系列机械男表WSRO0002",
        "info": "卡地亚（Cartier ）[1]  是一家法国钟表及珠宝制造商，于1847年由Louis-François Cartier在巴黎Rue Montorgueil 31号创办。现为瑞士历峰集团（Compagnie Financière Richemont SA）下属公司。1874 年， 其子亚法· 卡地亚继承其管理权， 由其孙子路易· 卡地亚、 皮尔· 卡地亚与积斯· 卡地亚将其发展成世界著名品牌。 1904 年曾为飞机师阿尔拔图· 山度士· 度门设计世界上首只戴在手腕的腕表—— 卡地亚山度士腕表（ Cartier Santos）。 ",
        "price": 54798,
        "image": "./src/images/img2.jpg",
        "count": 1,
        "isCheck": false
    },
    {
        "id": 3,
        "name": "浪琴(Longines)手表 名匠系列机械男表L2.793.4.78.3",
        "info": "浪琴（LONGINES）于1832年在瑞士索伊米亚创立，拥有逾180多年的悠久历史与精湛工艺，在运动计时领域亦拥有显赫传统与卓越经验。以飞翼沙漏为标志的浪琴表以优雅着称于世，作为全球领先钟表制造商斯沃琪集团旗下的著名品牌，浪琴表已遍布世界130多个国家。浪琴作为世界锦标赛的计时器及国际联合会的合作伙伴， 浪琴表品牌以其优雅的钟表享誉全球， 亦是世界领先钟表制造商 Swatch Group S.A.公司的旗下一员",
        "price": 13299,
        "image": "./src/images/img3.jpg",
        "count": 1,
        "isCheck": false
    }
]
export default dataArray;