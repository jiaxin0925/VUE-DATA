import mock from "mockjs"
import product from "./product"

export default mock.mock({
    "result": product
});