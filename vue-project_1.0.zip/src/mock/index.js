import axios from "axios"
import MockAdapter from "axios-mock-adapter"

import data from "./data/product"
import product from "./data/detail"
import music from "./data/music"

const mock = new MockAdapter(axios);
mock.onGet("http://localhost:8080/musicList").reply(200, music);
mock.onGet("http://localhost:8080/product").reply(200, product);
mock.onGet("http://localhost:8080/detail").reply((config) => {
    let detailId = config.params.id;
    return new Promise((resolve, reject) => {
        product.result.find((item) => {
            if (item.id == detailId) {
                resolve([200, item]);
            }
        });
    });
});
mock.onGet("http://localhost:8080/products").reply(200, data);

mock.onGet('http://localhost:8080/users').reply(200, {
    users: [
        { id: 1, username: 'heinan', password: '123456' },
        { id: 2, username: 'haonan', password: '666666' },
    ]
});