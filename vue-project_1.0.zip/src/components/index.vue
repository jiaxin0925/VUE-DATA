<template>
    <div>
        <headers>
            <div class="left ml15 pl15 mt3">
                <transition name="fade">
                    <p v-show="username">
                        <span v-if="username">您好 {{username}}，欢迎您。</span>
                        <span v-else>亲，请登陆</span>
                    </p>
                </transition>
            </div>
            <div class="right mt3">
                <el-select v-model="value" placeholder="请选择">
                    <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                </el-select>
            </div>
        </headers>
        <!-- <carousel></carousel> -->
        <div class="swiper-container" v-swiper style="height: 350px;">
            <div class="swiper-wrapper">
                <div class="swiper-slide">Slide 1</div>
                <div class="swiper-slide">Slide 2</div>
                <div class="swiper-slide">Slide 3</div>
            </div>
            <!-- 如果需要分页器 -->
            <div class="swiper-pagination"></div>
            <!-- 如果需要导航按钮 -->
            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>
            <!-- 如果需要滚动条 -->
            <div class="swiper-scrollbar"></div>
        </div>
        <div class="panel">
            <h3 class="panel-heading">今日热销</h3>
            <product-list></product-list>
        </div>
    </div>
</template>
<script>
import Headers from "./include/header.vue"
import ProductList from "./productList.vue"
import Carousel from "./carousel.vue"
export default {
    name: "home",
    data() {
        return {
            checked: true,
            options: [{
                value: '选项1',
                label: '黄金糕'
            }, {
                value: '选项2',
                label: '双皮奶'
            }, {
                value: '选项3',
                label: '蚵仔煎'
            }, {
                value: '选项4',
                label: '龙须面'
            }, {
                value: '选项5',
                label: '北京烤鸭'
            }],
            value: '',
            username: null
        }
    },
    mounted() {
        this.getToken();
    },
    methods: {
        getCookie(key) {
            return localStorage.getItem(key);
        },
        getToken() {
            if (localStorage.length > 0) {
                let token = this.getCookie("username");
                if (!token) {
                    alert("请登陆");
                    this.$router.push({ path: "/login" });
                } else {
                    let user = JSON.parse(this.getCookie("username")) || null;
                    this.username = user.username;
                }
            } else {
                alert("请登陆");
                this.$router.push({ path: "/login" });
            }

        }
    },
    components: {
        productList: ProductList,
        carousel: Carousel,
        headers: Headers
    }
}
</script>
<style scoped>
.right{
    top: 5px!important;
}

.fade-enter-active,
.fade-leave-active {
    opacity: 1;
    transition: all 1s;
}

.fade-enter,
.fade-leave-active {
    opacity: 0
}
</style>