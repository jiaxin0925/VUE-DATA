<template>
    <div>
        <headers :slide-right="showSlideRight">
            <h4>购物车</h4>
        </headers>
        <el-main>
            <header>
                <label for="checkall"> 全选 </label>
                <el-checkbox id="checkall" v-model="checkall" @click="selectAll"></el-checkbox>
            </header>
            <item :products="products" @update="compute"></item>
            <footer>
                <div>
                    总价：{{total}} 总shu：{{counts}}
                </div>
            </footer>
        </el-main>
    </div>
</template>
<script>
import axios from "axios";
import headers from "./include/header.vue";
import item from "./include/productItem.vue";

export default {
    name: "home",
    data() {
        return {
            showSlideRight: true,
            checkall: false,
            products: null,
            total: 0,
            counts: 0
        }
    },
    mounted() {
        this.getProducts();

    },
    methods: {
        getProducts() {
            axios({
                url: "http://localhost:8080/product"
            }).then((result) => {
                this.products = result.data["result"];
                this.compute();
            });
        },
        compute() {
            let tot = 0;
            let cou = 0;

            this.products.map((item, index) => {
                if (item.isCheck) {
                    tot += item.price * item.count;
                    cou += item.count;
                }
            })
            this.total = tot;
            this.counts = cou;
        },
        selectAll() {
            if (!this.checkall == true) {
                this.products.map((item, index) => {
                    item.isCheck = true;
                });
            } else {
                this.products.map((item, index) => {
                    item.isCheck = false;
                });
            }
            this.compute();
        }
    },
    components: {
        item,
        headers
    }
}
</script>
<style>
@import url("../css/font-awesome.min.css");
@import url("../css/bootstrap.min.css");
@import url("../css/reset.css");
@import url("../css/common.css");
</style>