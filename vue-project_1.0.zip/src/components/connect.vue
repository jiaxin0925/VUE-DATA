<template>
    <div>
        this is component connect
        <hr> {{message}}
        <tab1 :title="message" @update="onUpdate"></tab1>
        <tab2 :title="message" @update="onUpdate"></tab2>
    </div>
</template>
<script>
import tab1 from "./include/tab1.vue"
import tab2 from "./include/tab2.vue"
export default {
    name: "connect",
    data() {
        return {
            message: "this is tab"
        }
    },
    methods: {
        onUpdate(data) {
            console.log(data);
            this.message = data;
        }
    },

    components: {
        tab1,
        tab2
    }
}
</script>
<style>
</style>