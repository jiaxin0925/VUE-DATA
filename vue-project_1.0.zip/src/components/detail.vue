<template>
    <div>
        <headers>
            <h4>产品详情</h4>
        </headers>
        <div class="content p10">
            <h4 class="text-center">{{title}}</h4>
            <p class="mt15">{{content}}</p>
        </div>
    </div>
</template>
<script>
import Headers from "@/components/include/header.vue"
import axios from "axios"
export default {
    name: "",
    data() {
        return {
            title: null,
            content: null
        }
    },
    mounted() {
        this.getArtical();
    },
    methods: {
        getArtical() {
            let detailId = this.$route.query.id;
            axios.get("http://localhost:8080/detail", {
                params: {
                    id: detailId
                }
            }).then((result) => {
                this.title = result.data.name;
                this.content = result.data.info;
            });
        }
    },
    components: {
        headers: Headers
    }
}
</script>
<style>
</style>