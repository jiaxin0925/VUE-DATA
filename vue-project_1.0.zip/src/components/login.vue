<template>
    <div class="p10">
        <h3 class="text-center">学生信息管理</h3>
        <form class="col-xs-8 col-xs-offset-2">
            <div class="form-group">
                <label for="username">Email address</label>
                <input type="email" class="form-control" v-model="username" id="username" placeholder="请输入你的用户名">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" v-model="password" id="password" placeholder="请输入你的密码">
            </div>
            <div class="form-group">
                <button type="button" class="btn btn-default" @click="subForm">Submit</button>
                <button type="reset" class="btn btn-default">Rest</button>
            </div>
        </form>
    </div>
</template>
<script>
import axios from "axios"


export default {
    name: "login",
    data() {
        return {
            username: "",
            password: "",
            info: "123132131"
        }
    },
    mounted() {

    },
    methods: {
        setCookie(key, val) {
            localStorage.setItem(key, val)
        },
        subForm() {
            axios.get('http://localhost:8080/users')
                .then((response) => {
                    let result = response.data.users;
                    result.map((val, ind) => {
                        if (this.username == val.username) {
                            if (this.password == val.password) {
                                console.log(val);
                                this.setCookie("username", JSON.stringify(val));
                                // location.href = "#/index";
                                this.$router.push({path:"/index"});
                            } else {
                                alert(777);
                            }

                        }
                    });

                });
        }
    }
}
</script>
<style></style>