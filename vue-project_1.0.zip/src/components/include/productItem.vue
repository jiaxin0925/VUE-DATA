<template>
    <ul>
        <el-row class="pt15 pb15" :gutter="20" v-for="(product,index) in products">
            <el-col :span="2">
                <div class="grid-content text-center">
                    <el-checkbox v-model="product.isCheck" @click="checkItem(index)"></el-checkbox>
                    <!-- <input type="checkbox" v-model="product.isCheck" > -->
                </div>
            </el-col>
            <el-col :span="18">
                <div class="grid-content">
                    <dt class="col-xs-3 text-center">
                        <img :src="product.image" alt="">
                    </dt>
                    <dd class="col-xs-9">
                        <h4>{{product.name}}</h4>
                        <strong class="mt10 text-orange">{{product.price}}</strong>
                    </dd>
                </div>
            </el-col>
            <el-col :span="4">
                <div class="grid-content">
                    <el-input-number v-model="product.count" @change="changeCount(index)" :min="0" :max="20" label="描述文字"></el-input-number>
                    <!--  <span class="fa fa-plus p5 bd1" @click="add(index)"></span>
                    <input type="text" v-model="product.count" style="width: 50px;">
                    <span class="fa fa-minus p5 bd1" @click="del(index)"></span> -->
                </div>
            </el-col>
        </el-row>
        <!--  <li v-for="(product,index) in products" class="clearfix">
            <div class="col-xs-1">
            </div>
            <dl class="col-xs-9 clearfix">
                <dt class="col-xs-4">
                    <img :src="product.image" alt="">
                </dt>
                <dd class="col-xs-8">
                    <h4>{{product.name}}</h4>
                    <p>{{product.price}}</p>
                </dd>
            </dl>
            <div class="col-xs-2">
            </div>
        </li> -->
    </ul>
</template>
<script>
export default {
    name: "productItem",
    data() {
        return {

        }
    },
    props: ["products"],
    methods: {
        // add($index) {
        //     this.products[$index].count += 1;
        //     this.$emit("update");
        // },
        // del($index) {
        //     if (this.products[$index].count < 1) return;
        //     this.products[$index].count -= 1;
        //     this.$emit("update");
        // },
        changeCount(index) {
            this.$emit("update");
        },
        checkItem(index) {
            let temp = [];
            this.products[index].isCheck = !this.products[index].isCheck;
            this.products.map((item, index) => {
                console.log(item.isCheck);
                if (item.isCheck == true) {
                    temp.push(item);
                }
            });
            if (temp == this.products.length) {
                this.checkall = true;
            } else {
                this.checkall = false;
            }
            this.$emit("update");
        },
    }
}
</script>
<style>
</style>