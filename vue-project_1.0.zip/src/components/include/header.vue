<template>
    <header class="header">
        <div class="float-right" v-show="slideRight">
            <router-link :to="{path:'/index'}" class="pl5 pr5 text-white">
                <i class="fa fa-cart-plus"></i>
            </router-link>
            <router-link :to="{path:'/music'}" class="pl5 pr5 text-white">
                <i class="fa fa-music"></i>
            </router-link>
            <router-link :to="{path:'/index'}" class="pl5 pr5 text-white">
                <i class="fa fa-user-circle-o"></i>
            </router-link>
        </div>
        <router-link :to="{path:'/index'}" class="left text-white">
            <i class="fa fa-angle-left fa-2x"></i>
        </router-link>
        <slot>
            <h4>学生管理平台</h4>
        </slot>
    </header>
</template>
<script>
export default {
    // props:["slideRight"],
    props: {
        slideRight: {
            type: Boolean,
            // required: true,
            default: false
        }
    },
    data() {
        return {}
    }
}
</script>
<style scoped>
.header {
    background-color: #099fde;
    padding: 15px;
    text-align: center;
    color: #fff;
    height: 56px;
}

.header .left {
    position: absolute;
    top: 15px;
    left: 15px;
}

.header .right {
    position: absolute;
    top: 15px;
    right: 15px;
}

.header .right input[type="checkbox"] {
    vertical-align: sub;
}
</style>