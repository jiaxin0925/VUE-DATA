<template>
    <div>
        this is component Parent: {{title}}<br>
        this is component Tab1: {{info}}<br>
        <button type="button" @click="go">点我</button>
    </div>
</template>
<script>
export default {
    name: "tab2",
    props: {
        title: {
            type: String,
            require: false
        }
    },
    data() {
        return {
            info:null
        }
    },
    mounted() {
        hub.$on('siblingUpdate', (val) => {
            this.info = val;
        });
    },
    methods: {
        go() {
            let data = this.title + 666;
            this.$emit("update", data);
        }
    }
}
</script>
<style>
</style>