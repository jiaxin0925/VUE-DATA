<template>
    <div>
        this is component Tab: {{title}}
        <button type="button" @click="go">点我</button>
        <button type="button" @click="gogo">同级传值</button>
    </div>
</template>
<script>
export default {
    name: "tab1",
    props: {
        title: {
            type: String,
            require: false
        }
    },
    data() {
        return {}
    },
    methods: {
        go() {
            let data = this.title + 666;
            this.$emit("update", data);
        },
        gogo() {
            hub.$emit("siblingUpdate", 666);
        }
    }
}
</script>
<style>
</style>