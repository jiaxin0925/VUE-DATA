<template>
    <div>
        {{point}}
        <select v-model="point" @change="goto(point['address'])">
            <option v-for="item in users" :value="item">{{item.name}}</option>
        </select>
        <div id="map"></div>
    </div>
</template>
<script>
let config = { "x": 116.417, "y": 39.909 }
export default {
    name: "",
    data() {
        return {
            point: null,
            users: [{
                name: "李雷",
                address: {
                    x: 112.5475,
                    y: 37.76121
                }
            }, {
                name: "韩梅梅",
                address: {
                    x: 116.3062361771,
                    y: 40.0482412144
                }
            }]
        }
    },
    mounted() {
        this.showmap();
    },
    methods: {
        goto(point) {
            this.showmap(point);
        },
        showmap(point = config) {
            var mapwrap = document.getElementById("map");
            var map = new BMap.Map(mapwrap);
            // 初始化地图,设置中心点坐标和地图级别
            var point = new BMap.Point(point.x, point.y);
            var foxPoint = new BMap.Point(point.x, point.y);
            map.centerAndZoom(point, 15);




            var foxIcon = new BMap.Icon("http://lbsyun.baidu.com/jsdemo/img/fox.gif", new BMap.Size(300, 157));
            var marker = new BMap.Marker(foxPoint, { icon: foxIcon });

            map.addOverlay(marker);
            //添加地图类型控件
            map.addControl(new BMap.MapTypeControl({
                mapTypes: [
                    BMAP_NORMAL_MAP,
                    BMAP_HYBRID_MAP
                ]
            }));
            // 设置地图显示的城市 此项是必须设置的
            map.setCurrentCity("北京");
            //开启鼠标滚轮缩放
            map.enableScrollWheelZoom(true);

        }
    }
}
</script>
<style>
#map {
    position: absolute;
    top: 50px;
    bottom: 0;
    width: 100%;
}
</style>