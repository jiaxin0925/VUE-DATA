<template>
    <div>
        <headers>
            <div>
                音乐 - {{name}}
            </div>
        </headers>
        <div class="box">
            <audio autoplay="autoplay">
                <source :src="url">
            </audio>
            <div class="pic">
                <img :src="image" alt="">
            </div>
        </div>
    </div>
</template>
<script>
import Headers from "./include/header.vue"
export default {
    name: "player",
    data() {
        return {
            url: null,
            name: null,
            image: "./src/images/musicbg.gif",
        }
    },
    mounted() {
        this.media();
    },
    methods: {
        media() {
            this.url = this.$route.query.url;
            this.name = this.$route.query.name;
        }
    },
    components: {
        headers: Headers
    }
}
</script>
<style scoped>
.box {
    width: 0.8rem;
    height: 0.8rem;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    margin: auto;
}

.box .pic {
    width: 0.8rem;
    height: 0.8rem;
    position: relative;
}

.box .pic img {
    width: 100%;
    height: 100%;
    border-radius: 100%;
}

.box .pic .btn>i {
    position: absolute;
    left: 40%;
    bottom: 30%;
}

@-webkit-keyframes rotate {
    from {
        -webkit-transform: rotate(0deg);
    }
    to {
        -webkit-transform: rotate(360deg);
    }
}

#aud {
    width: 50px;
    height: 50px;
    display: block!important
}
</style>