<template>
    <div class="">
        <ul class="list-group">
            <li v-for="(product,index) in products" class="clearfix list-group-item">
                <router-link :to="{path:'/detail',query: {id: ++index}}">
                    <dl class="clearfix">
                        <dt class="col-xs-4 text-center">
                            <img :src="product.image" alt="">
                        </dt>
                        <dd class="col-xs-8">
                            <h4>{{product.name}}</h4>
                            <p class="text-orange mt10">{{product.price}}</p>
                        </dd>
                    </dl>
                </router-link>
            </li>
        </ul>
    </div>
</template>
<script>
import axios from "axios"
export default {
    name: "",
    data() {
        return {
            products: null
        }
    },
    mounted() {
        this.getProducts()
    },
    methods: {
        getProducts() {
            axios.get("http://localhost:8080/products").then((result) => {
                console.log(result);
                this.products = result.data;
            });
        },
        compute() {
            let tot = 0;
            let cou = 0;
            this.products.map((item, index) => {
                if (item.isCheck) {
                    tot += item.price * item.count;
                    cou += item.count;
                }
            })
            this.total = tot;
            this.counts = cou;
        },
        add($index) {
            this.products[$index].count += 1;
            this.compute();
        },
        del($index) {
            if (this.products[$index].count < 1) return;
            this.products[$index].count -= 1;
            this.compute();
        },
        checkItem() {
            this.compute();
            let temp = 1;
            this.products.forEach((item, index) => {
                if (item.isCheck == true) {
                    temp++;
                }
            });
            if (temp == this.products.length) {
                this.checkall = true;
            } else {
                this.checkall = false;
            }

        },
        selectAll() {
            if (!this.checkall == true) {
                this.products.map((item, index) => {
                    item.isCheck = true;
                });
            } else {
                this.products.map((item, index) => {
                    item.isCheck = false;
                });
            }
        }
    }
}
</script>
<style>
</style>