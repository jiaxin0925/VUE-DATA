<template>
    <div>
        <headers>
            <div>
                音乐
            </div>
        </headers>
        <div class="nav">
            <ul>
                <li class="nav-item bdb1" v-for="(value,key,index) in musics">
                    <span @click="show(index)">{{key}}</span>
                </li>
            </ul>
            <transition enter-active-class="animated bounceInDown" leave-active-class="animated fadeOutUp">
                <p v-show="flag">
                    <ol v-for="(value,key,index) in musics">
                        <li>
                            <h3>{{key}}</h3>
                            <p v-for="val in value"> {{val.name}}</p>
                        </li>
                    </ol>
                </p>
            </transition>
        </div>
        <div class="list-group">
            <div class="list-group-item">
                <ol v-for="(value,key,index) in musics">
                    <li v-for="val in value">
                        <router-link :to="{path:'/player',query:{url:val.url,name:val.name}}">{{val.name}}</router-link>
                    </li>
                </ol>
            </div>
        </div>
    </div>
</template>
<script>
import axios from "axios"
import Headers from "./include/header.vue"
export default {
    name: "",
    data() {
        return {
            musics: null,
            flag: false
        }
    },
    mounted() {
        this.getMuscList();
    },
    methods: {
        getMuscList() {
            axios.get("http://localhost:8080/musicList", {
                    params: {
                        id: 1
                    }
                })
                .then((result) => {

                    this.musics = result.data;
                });
        },
        show($index) {
            this.flag = !this.flag;
            let ols = document.querySelectorAll("ol");
            [...ols].find((item, index) => {
                if (index == $index) {
                    item.className = "";

                } else {
                    item.className = "hide";
                }
            });
        }
    },
    components: {
        headers: Headers
    }
}
</script>
<style>
@import url("../css/animate.css");
.nav {
    position: relative;
    overflow: hide;
}

.nav ul {
    display: -webkit-flex
}

.nav-item {
    -webkit-flex: 1;
    height: 50px;
    line-height: 50px;
    text-align: center;
}

.nav ol {
    height: 350px;
    background-color: #dec;
}
</style>