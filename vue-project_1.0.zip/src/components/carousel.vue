<template>
    <div class="carousel">
        <ol class="content">
            <li v-for="(item,index) in imgs">
                <img :src="item" alt="">
            </li>
        </ol>
        <button class="btn btn-default btn-prev" type="button" @click="prev">
            <span class="fa fa-angle-left"></span>
        </button>
        <button class="btn btn-default btn-next" type="button" @click="next">
            <span class="fa fa-angle-right"></span>
        </button>
    </div>
</template>
<script>
export default {
    name: "carousel",
    data() {
        return {
            oIndex: 0,
            touch: {
                startX: 0,
                endX: 0
            },
            imgs: ["./src/images/banner/img1.jpg", "./src/images/banner/img2.jpg", "./src/images/banner/img3.jpg", "./src/images/banner/img4.jpg", "./src/images/banner/img5.jpg"],
        }
    },
    mounted() {
        this.addEvents()
    },
    methods: {
        next() {
            if (this.oIndex >= this.imgs.length - 1) return;
            this.changeImage(++this.oIndex);
        },
        prev() {
            if (this.oIndex < 1) return;
            this.changeImage(--this.oIndex);
        },
        changeImage($index) {
            let lis = document.querySelectorAll("ol li");
            [...lis].find((item, index) => {
                if (index == $index) {
                    item.style.display = "block";
                } else {
                    item.style.display = "none";
                }
            })
        },
        addEvents() {
            document.addEventListener("touchstart", (event) => {
                this.touch.startX = event.touches[0].clientX;
            });
            document.addEventListener("touchmove", (event) => {
                this.touch.endX = event.touches[0].clientX;
            });
            document.addEventListener("touchend", (event) => {
                let absStep = Math.abs(this.touch.startX - this.touch.endX);
                if (this.touch.startX > this.touch.endX) {
                    this.next()
                } else {
                    this.prev()
                }
                this.touch.startX = 0;
                this.touch.endX = 0;
            });
        }
    }
}
</script>
<style scoped>
.carousel {
    background-color: #dec;
    position: relative;
}

.title {
    height: 50px;
    display: -webkit-flex
}

.btn-prev,
.btn-next {
    position: absolute;
    top: 45%;
}

.btn-prev {
    left: 0;
}

.btn-next {
    right: 0;
}

.content {
    height: 350px;
    overflow: hidden;
}

.content li img {
    height: 350px;
    width: 100%
}
</style>