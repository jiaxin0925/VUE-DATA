<template>
    <router-view/>
</template>
<script>
import Vue from "vue"
Vue.component("tab", {
    props: ["title", "content"],
    mounted() {
        this.go();
    },
    template: `<div>
                {{title}}<br/>
                {{content}}
            </div>`,
    methods: {
        go() {
            // console.log("this is tab");
        }
    }
});
export default {
    name: "home",
    data() {
        return {
            title: "这是标题",
            content: "这是内容",
            flag: true,
            username: null,
            info: {
                color: "green"
            }

        }
    },
    watch: {
        flag(newValue, oldValue) {

            if (newValue == true) {
                this.info = {
                    color: "green"
                }
            } else {
                this.info = {
                    color: "#f00"
                }
            }
        }
    },
    computed: {
        aaa() {
            let info = null;
            if (this.flag) {
                info = {
                    color: "green"
                }
            } else {
                info = {
                    color: "#f00"
                }
            }
            return info;
        }
    },
    methods: {
        sub() {
            if (this.username == "heinan") {
                this.flag = true;
            } else {
                this.flag = false;
            }
        }
    },
    components: {
        tab1: {
            props: ["title", "content"],
            template: `<div>
                {{title}}<br/>
                {{content}}
            </div>`,
            mounted() {
                this.go();
            },
            methods: {
                go() {
                    console.log("this is tab1");
                }
            }
        }
    }
}
</script>
<style>
@import url('../node_modules/element-ui/lib/theme-chalk/index.css');

@import url("./css/font-awesome.min.css");
@import url("./css/bootstrap.min.css");
@import url("./css/swiper-3.4.2.min.css");
@import url("./css/reset.css");
@import url("./css/common.css");
</style>