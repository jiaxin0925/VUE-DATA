import Vue from "vue"
import ElementUI from "element-ui"

import VueVideoPlayer from 'vue-video-player'


import App from "@/app.vue"
import Router from "@/router"
import "@/mock"

const eventHub = new Vue();
Vue.prototype.hub = eventHub;
window.hub = eventHub;

import Swiper from "@/js/swiper-3.4.2.min.js"

Vue.use(ElementUI);
Vue.use(VueVideoPlayer);

Vue.directive('swiper', function(el, bind) {
    setTimeout(function() {
        new Swiper(el, {
            loop: true,
            pagination: '.swiper-pagination',
            nextButton: '.swiper-button-next',
            prevButton: '.swiper-button-prev'
        })
    })
});

new Vue({
    el: "#app",
    router: Router,
    template: "<App/>",
    components: {
        App
    }
})