import login from "@/components/login.vue"
import index from "@/components/index.vue"
import detail from "@/components/detail.vue"
import music from "@/components/music.vue"
import video from "@/components/video.vue"
import player from "@/components/player.vue"
import shopcar from "@/components/shopcar.vue"
import connect from "@/components/connect.vue"
import map from "@/components/map.vue"

const routerConfig = [{
        path: "/login",
        name: "login",
        component: login
    },
    {
        path: "/index",
        name: "index",
        component: index
    },
    {
        path: "/detail",
        name: "detail",
        component: detail
    },
    {
        path: "/music",
        name: "music",
        component: music
    },
     {
        path: "/video",
        name: "video",
        component: video
    },
    {
        path: "/player",
        name: "player",
        component: player
    },
    {
        path: "/shopcar",
        name: "shopcar",
        component: shopcar
    },
    {
        path: "/connect",
        name: "connect",
        component: connect
    },
    {
        path: "/map",
        name: "map",
        component: map
    }
]
export default routerConfig;