import Vue from 'vue';
import '../index.html';
import rem from './js/base/rem';
import './css/style.css';
import './iconfont/iconfont.css';
import VueRouter from 'vue-router';
import { routes } from './js/common/routes';
import header from './component/template/header/header.vue';
import footer from './component/template/footer/footer.vue';
import bus from './js/plugin/bus.js';
import format from './js/plugin/formatParams.js'
import axios from 'axios';

Vue.prototype.axios = axios;

rem(3.2);

const router = new VueRouter({
    routes
})
// VueRouter 是一个插件 需要 use 一下 。
Vue.use(VueRouter); // 使用 vue 插件 vue-router.

Vue.use(bus);

Vue.use(format);

new Vue({
    el:'#app',
    data(){
        return {
            msg:'Hello!',
            list:[ 
                {text:'外卖',path:'/takeout',icon:'icon-changyonglogo40'},
                {text:'分类',path:'/classify',icon:'icon-fenlei'},
                {text:'订单',path:'/order',icon:'icon-icon-'},
                {text:'我的',path:'/my',icon:'icon-home'}
            ],
            title:'外卖'
        }
    },
    router,
    components:{
        tabBar:footer,
        navigation:header
    }
})