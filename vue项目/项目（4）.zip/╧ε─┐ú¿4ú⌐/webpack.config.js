
var webpack = require('webpack')
var HtmlWebpackPlugin = require('html-webpack-plugin');
// var UglifyJsWebpackPlugin = require('uglifyjs-webpack-plugin');
var path = require('path');
var url = require('url');
var qs = require('querystring');
var fs = require('fs')
module.exports = {
    entry:'./src/entry.js',
    output:{
        filename:'bundle.js',
        path:path.resolve(__dirname,'dist')
    },
    module:{
        rules:[
            {test:/\.js$/,use:['babel-loader']},
            {test:/\.css$/,use:['style-loader','css-loader']},
            {test:/\.(png|jpg|gif|svg|jpeg|eot|woff|ttf)$/,use:['url-loader']},
            {test:/\.html$/,use:['html-loader']},
            {test:/\.vue$/,use:['vue-loader']},
            {test:/\.scss$/,use:['sass-loader']}
        ]
    },
    resolve:{
        alias:{
            'vue': 'vue/dist/vue.js'
        }
    },
    plugins:[
        new HtmlWebpackPlugin({
            template:'./index.html'
        }),
        // new UglifyJsWebpackPlugin(),
        new webpack.HotModuleReplacementPlugin()
    ],
    devServer:{
        contentBase:__dirname,
        port:8080,
        open:true,
        setup(app){

        var arr = new Array(12);
        
        for(var i = 0 ; i<arr.length; i++){
           var imageData  = fs.readFileSync('./src/img/'+(i+1)+'.png');
           var imageBuffer = new Buffer(imageData);
           var imageBase64 = 'data:image/png;base64,'+ imageBuffer.toString('base64');
           arr[i] = imageBase64;
        }

        var dataBase={
            foodtypelist:[
                { type:'美食',image:arr[0]},
                { type:'早餐',image:arr[1]},
                { type:'商超便利',image:arr[2] },
                { type:'果蔬生鲜',image:arr[3] },
                { type:'大牌5折',image:arr[4] },
                { type:'甜品饮品',image:arr[5] },
                { type:'医药健康',image:arr[6] },
                { type:'浪漫鲜花',image:arr[7] },
                { type:'麻辣烫',image:arr[8] },
                { type:'地方菜系',image:arr[9] },
                { type:'披萨意面',image:arr[10] },
                { type:'新店特惠',image:arr[11] }
            ]
        }
            app.get('/mock/*',(req,res)=>{
                var urlObj =  url.parse(req.url);
                console.log(urlObj.pathname)
                switch(urlObj.pathname){
                    case '/mock/getfoodtypelist':
                    res.setHeader('content-type','application/json;charset=utf-8');
                    res.write(JSON.stringify(dataBase['foodtypelist']))
                    res.end()
                    break;
                    default :
                    res.end('该接口暂未提供。')
                    break;
                }

            })
            app.post('/mock/*',(req,res)=>{
                var urlObj =  url.parse(req.url);
                var str = '';
                req.on('data',(chunk)=>{
                    str+=chunk;
                })
                req.on('end',()=>{
                    var postParams = qs.parse( str );
                    switch(urlObj.pathname){
                        case '/mock/login':
                        res.end('这是个假接口');
                        break;
                        default:
                        res.end('暂未提供。')
                        break;
                    }
                })
                
            })
        }       
    },
    devtool:'cheap-source-map'
}