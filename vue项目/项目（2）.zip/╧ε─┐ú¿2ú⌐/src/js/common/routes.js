import takeOut from '../../component/router/take-out.vue'
import classify from '../../component/router/classify.vue'
import order from '../../component/router/order.vue'
import my from '../../component/router/my.vue'

export const routes = [
    { path:'*',redirect:'/takeout' },
    { path:'/takeout',component:takeOut },
    { path:'/classify',component:classify },
    { path:'/order',component:order },
    { path:'/my',component:my }
]

export default routes;
