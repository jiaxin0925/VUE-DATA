<template>
  <div>
      <div>
          <search :iconfont="iconfont" :text="text"></search>
      </div>
  </div>
</template>

<script>
import search from '../template/search/search.vue';
export default {
    data(){
        return {
            title:'分类',
            text:'搜索商家、商品名称',
            iconfont:'icon-sousuo'
        }
    },
    components:{
        search
    },
    created(){ 
        this.bus.$emit('updataTitle',this.title);
    }
}
</script>

<style>

</style>

