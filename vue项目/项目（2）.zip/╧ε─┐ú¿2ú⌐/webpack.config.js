var webpack = require('webpack')
var HtmlWebpackPlugin = require('html-webpack-plugin');
// var UglifyJsWebpackPlugin = require('uglifyjs-webpack-plugin');
var path = require('path')


module.exports = {
    entry:'./src/entry.js',
    output:{
        filename:'bundle.js',
        path:path.resolve(__dirname,'dist')
    },
    module:{
        rules:[
            {test:/\.js$/,use:['babel-loader']},
            {test:/\.css$/,use:['style-loader','css-loader']},
            {test:/\.(png|jpg|gif|svg|jpeg|eot|woff|ttf)$/,use:['url-loader']},
            {test:/\.html$/,use:['html-loader']},
            {test:/\.vue$/,use:['vue-loader']}
        ]
    },
    resolve:{
        alias:{
            'vue': 'vue/dist/vue.js'
        }
    },
    plugins:[
        new HtmlWebpackPlugin({
            template:'./index.html'
        }),
        // new UglifyJsWebpackPlugin(),
        new webpack.HotModuleReplacementPlugin()
    ],
    devServer:{
        contentBase:__dirname,
        port:8080,
        open:true
    },
    devtool:'eval'
}