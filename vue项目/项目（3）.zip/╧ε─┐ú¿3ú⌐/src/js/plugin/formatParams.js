export default {
    install:(Vue,options)=>{
        if(!Vue.prototype.format){
            Vue.prototype.format = function(obj){
                if(obj instanceof Object && !(obj instanceof Array) ){
                    let str = '';
                    function formatfn(obj){
                        for(let key in obj){
                            if(typeof obj[key] !=='object'){
                                str += key+'='+ obj[key]+'&';
                            }else{
                                formatfn(obj[key]);
                            }
                            
                        }
                    }
                    formatfn(obj);
                    str = str.substring(0,str.length-1);
                    return str;

                }else{
                    throw 'Params must be an object!';
                }
            }
        }else{
            throw 'The attribute format early exist!'
        }
        
    }
}