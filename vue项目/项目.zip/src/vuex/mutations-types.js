export const CHANGE_MSG = 'CHANGE_MSG';
// export const CHANGE_OTHER = 'CHANGE_MSG';
