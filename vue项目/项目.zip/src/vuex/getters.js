export default {
    changeMsg(state) {
        return state.msg.replace('Vuex!', 'getters!');
    },
};
