export default {
    msg: 'Hello Vuex!',
};
