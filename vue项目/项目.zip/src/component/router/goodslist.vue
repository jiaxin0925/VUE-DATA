<template>
    <div class="content">
        <div class="">
            <goods v-for="item in goodsList"
                :goodsName="item.name"
                :goodsPrice="item.price"
                :goodsIcon="item.img"
                :key="item.name"
            >
            </goods>
        </div>
    </div>
</template>

<script>

import goods from './goodslist/goods.vue';

export default {
    data() {
        return {
            goodsList: [],
        };
    },
    components: {
        goods,
    },
    created() {
        console.log('创建了');
        this.axios({
            url: 'http://localhost:8080/mock/storedetaillist',
            method: 'POST',
            data: this.format({
                type: this.$route.params.foodtype,
            }),
        })
            .then((result) => {
                console.log(result.data);
                this.goodsList = result.data;
            }, (error) => {
                throw error;
            });
    },
    beforeRouteUpdate(to, from, next) {
        this.axios({
            url: 'http://localhost:8080/mock/storedetaillist',
            method: 'POST',
            data: this.format({
                type: this.$route.params.foodtype,
            }),
        }).then((result) => {
            console.log(result.data);
            this.goodsList = result.data;
            next();
        }, (error) => {
            throw error;
        });
    },
};
</script>

<style scoped>
.content {
  height: 100%;
  overflow-y: scroll;
}
</style>
