import Vue from 'vue'
import Router from 'vue-router'

import Shopcar from '@/components/shopcar.vue'

Vue.use(Router)

export default new Router({
  routes: [{
    path: '/shopcar',
    name: 'shopcar',
    component: Shopcar
  }, ]
})
