export default [{
    id: 1,
    name: "杯子",
    price: 100,
    infomation: "这个杯子好漂亮",
    count: 1,
    isCheck: true
  },
  {
    id: 2,
    name: "牙刷",
    price: 35,
    infomation: "这个牙刷不错哦",
    count: 2,
    isCheck: false
  }, {
    id: 3,
    name: "袜子",
    price: 25,
    infomation: "这双袜子很舒服",
    count: 5,
    isCheck: true
  }
]
