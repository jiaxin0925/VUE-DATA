# 组件定义三方式
//注意：组件名称不能够与html节点相同，否则报错


1、全局组件

Vue.component("headers", {
  name: "headers",
  template: "<div> <h1>this is header</h1></div>",
  mounted() {

  },
  computed: {

  },
  methods: {

  }
});
2、局部组件
//只能在当前页面使用
 components: {
    footers: {
      name: "footers",
      template: "<div><h1>this is footer</h1></div>",
      mounted() {

      },
      computed: {

      },
      methods: {

      }
    },
  }
3、组件延伸 - .vue

.vue 文件
<template>
	//模板只能有一个子节点，否则报错
	<div>
		<h1></h1>
		<p></p>
	</div>
</template>
<script>
	export default {
		name:"组件名称",
		...
	}
</script>
//scoped 设置样式只在当前组件生效
<style scoped>
	
</style>




购物车
1、实现购物车路由页面
2、实现购物车接口数据
3、请求产品并渲染
4、绑定点击事件