// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'

//因为我要做单页面应用  所以说我要用路由
//实例化时需要使用一个模板（组件）页面，所以引入App,并且Vue中要使用一个模板，需要在components中注册组件
new Vue({
  el: '#app',
  router,
  //局部组件
  components: {
    App: App
  },
  //模板
  template: '<App/>'
})
