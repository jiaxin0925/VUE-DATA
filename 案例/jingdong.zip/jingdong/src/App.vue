<template>
  <div id="app">
    <router-view class='main'/>
       <footer-cell v-if='flag()==="1"'>
        <footer-item 
        :text='item.text' 
        :icon='item.icon' 
        v-for='(item,idx) in arr'
        :key='idx' 
        :router-find='routerFinds'
        :name='item.name'
        ></footer-item> 
    </footer-cell>
  </div>
</template>

<script>
import '../static/css/style.css'
import '../static/css/common.css'
import '../static/css/reset.css'
import '../static/icon/iconfont.css'
import arr from './mock/data/routeLink'
import foots from './components/Footer'
export default {
  name: 'app',
  data(){
    return {
      arr
    }
  },
  components:{
  	FooterCell:foots.FooterCell,
  	FooterItem:foots.FooterItem
  },
  methods:{
    routerFinds(name){
      this.$router.push({name:name})
    },
    flag(){
      return window.localStorage['flag']
    }
  }
}
</script>
