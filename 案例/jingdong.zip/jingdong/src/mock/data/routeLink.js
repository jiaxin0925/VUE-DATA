export default [{
  path: '/index',
  name: 'index',
  text: '首页',
  icon: 'iconfont icon-shouye'
}, {
  path: '/classify',
  name: 'hot',
  text: '分类',
  icon: 'iconfont icon-shouye'
}, {
  path: '/find',
  name: 'find',
  text: '发现',
  icon: 'iconfont icon-shouye'
}, {
  path: '/shop',
  name: 'shop',
  text: '购物车',
  icon: 'iconfont icon-shouye'
}, {
  path: '/home',
  name: 'home',
  text: '我的',
  icon: 'iconfont icon-wode'
}]
