<template>
	<div @click='routerFind(name)'>
		<i :class='icon'></i>{{text}}
	</div>
</template>
<script>
	export default {
		props:{
			text:{
				type:String,
				required:true
			},
			icon:{
				type:String,
				required:true
			},
			routerFind:{
				type:Function
			},
			name:{
				type:String
			}
		}
	}
</script>