<template>
	<div class="footer">
		<slot></slot>
	</div>
</template>