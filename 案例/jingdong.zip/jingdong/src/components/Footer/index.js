import FooterCell from './FooterCell'
import FooterItem from './FooterItem'
export default {
	FooterCell,
	FooterItem
}