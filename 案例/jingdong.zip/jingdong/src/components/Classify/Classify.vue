<template>
  <div>
  	<div class="left">
  		<router-link :to='{name:"hot",params:{id:1}}'>热门</router-link>
  		<router-link :to='{name:"cs",params:{id:2}}'>超市</router-link>
  		<router-link :to='{name:"mp",params:{id:3}}'>名牌</router-link>	
  	</div>
  	<div class="right">
  		<router-view/>
  	</div>
  </div>
</template>



