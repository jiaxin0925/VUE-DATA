<template>
	<div>
		超市
	</div>
</template>