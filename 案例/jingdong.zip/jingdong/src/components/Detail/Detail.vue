<template>
	<div>
		<img :src='detail !==null && detail.imageurl' alt="">
		{{detail!==null && detail.wname}}
	</div>
</template>
<script>
	export default {
		data(){
			return {
				detail:null
			}
		},
		mounted(){
			this.detail = JSON.parse(this.$route.params.jdDetail)
		}
	}
</script>