<template>
	<div class="swiperBox">
		<swiper :options="swiperOption"  ref="mySwiper" :class>   
		    <swiper-slide v-for="(item,idx) in arr" :key='idx'> 
		        <img :src="item" class="index_img">
		    </swiper-slide>  
		    <div class="swiper-pagination" slot="pagination"></div>  
	 	</swiper> 
 	</div>
</template>
<script>
import { swiper, swiperSlide } from 'vue-awesome-swiper'
    export default{
        components: {  
            swiper,  
            swiperSlide  
        },  
        data() {  
            return {
                arr:["./static/images/1.jpg","./static/images/2.jpg","./static/images/3.jpg","./static/images/4.jpg","./static/images/5.jpg","./static/images/6.jpg"],
                swiperOption: {  
                	notNextTick:true,
                    pagination:{
                    	el:".swiper-pagination"
                    },
                    autoplay:2000,
                    loop:true,  
                    slidesPerView: 'auto',  
                    centeredSlides: true,  
                    paginationClickable: true,
                    onSlideChangeEnd: swiper => {  
                        this.page = swiper.realIndex+1;  
                        this.index = swiper.realIndex;  
                    },  
                }
            }  
        },   
        computed: {  
            swiper() {  
              return this.$refs.mySwiper.swiper;  
            }  
        },  
        mounted () {  
           	// var that = this;
           	// this.swiper.slideTo(0,0,false);
           	// setInterval(function(){
           	// 	that.swiper.slideNext()
           	// },1000)
        }  


    }
</script>
<style>
	.index_img{
		width: 100%;
	}
</style>