<template>  
    <div>
        {{getName()}}
        <swiper></swiper>
        <list v-for='(item,idx) in data'
        :key='idx'
        :title='item.wname'
        :url='item.imageurl'
        :jdListClick='jdListClick'
        :item='item'
        >
        </list>
    </div>
</template>  
<script>  
import Swiper from './Swiper'
export default {
    components:{
        Swiper
    },
    data(){
    	return {
    		data:null
    	}
    },
    mounted(){
    	this.$http('/index/recommend')
    	.then((res)=>{
            this.data = JSON.parse(res.data.recommend).wareInfoList
    	})
    },
    methods:{
        jdListClick(jdDetail){
            window.localStorage['title']=jdDetail.wname
            this.$router.push({name:'detail',params:{jdDetail:JSON.stringify(jdDetail)}})
        },
        getName(){
            return window.localStorage['title']
        }
    }

}
</script>  