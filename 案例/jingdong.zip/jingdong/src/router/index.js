import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const router = new Router({
  routes: [{
    path: '/index',
    name: 'index',
    component: () =>
      import ('@/components/Index')
  }, {
    path: '/classify',
    name: 'classify',
    component: () =>
      import ('@/components/Classify'),
    children: [{
      path: 'hot/:id',
      name: 'hot',
      component: () =>
        import ('@/components/Classify/Hot')
    }, {
      path: 'cs/:id',
      name: 'cs',
      component: () =>
        import ('@/components/Classify/Cs')
    }, {
      path: 'mp/:id',
      name: 'mp',
      component: () =>
        import ('@/components/Classify/Mp')
    }]

  }, {
    path: '/find',
    name: 'find',
    component: () =>
      import ('@/components/Find')
  }, {
    path: '/shop',
    name: 'shop',
    component: () =>
      import ('@/components/Shop')
  }, {
    path: '/home',
    name: 'home',
    component: () =>
      import ('@/components/Home')
  }, {
    path: '/detail/:jdDetail',
    name: 'detail',
    component: () =>
      import ('@/components/Detail')
  }]
})

router.beforeEach((to, from, next) => {
  if (to.name === 'detail') {
    window.localStorage['flag'] = 0
  } else {
    window.localStorage['flag'] = 1
  }
  next()
})
export default router
