import Vue from 'vue'
import axios from 'axios'
const tools = {
  install() {
    Object.defineProperty(Vue.prototype, "$http", {
      value: axios
    })
    Vue.component('list', {
      template: `
                <div @click='jdListClick(item)'>
                    <img v-lazy='url' alt="">
                    <h5>{{title}}</h5>
                </div>
            `,
      props: {
        url: {
          type: String
        },
        title: {
          type: String
        },
        jdListClick: {
          type: Function,
          default: () => { console.log('----') }
        },
        item: {
          type: Object
        }
      }


    })
  }
}

export default tools
