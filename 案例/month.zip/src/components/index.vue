<template>
  <div class="hello">
    <cont class="section"></cont>
    <foot class="footer"></foot>
  </div>
</template>

<script>
import cont from './cont.vue';
import foot from './foot.vue';
export default {
  name: 'HelloWorld',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  },
  components:{
   cont,
   foot
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
@import '../../static/css/reset.css';
@import '../../static/css/common.css';
.hello{
  position: absolute;
  top:0;
  right:0;
  bottom:0;
  left:0;
  display: flex;
  flex-direction: column;
  font-size: .12rem;
}
.section{
  flex:1;
  overflow-y: scroll;
}
.footer{
  height: .5rem;
}
</style>
