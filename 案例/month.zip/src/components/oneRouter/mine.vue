<template>
  <div class="mine-box">
      的反馈结果
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
