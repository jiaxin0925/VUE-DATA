<template>
  <div class="news-box">
      的反馈给
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
