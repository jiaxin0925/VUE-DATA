<template>
  <div class="home-box">
      空格分隔
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
