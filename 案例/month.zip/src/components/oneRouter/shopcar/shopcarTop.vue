<template>
  <div class="shopcarTop-box">
      <div class="shopcar-item" v-for="(item,index) in data" :key="index">
          <div class="shopcar-hotel">
                <input type="checkbox" v-model="item.flag" @click="itemHotel(item)">
                <label>{{item.shopName}}</label>
          </div>
          <div class="shopcar-product" v-for="(items,index) in item.value" :key="index">
              <div class="product-ins">
                  <input type="checkbox" v-model="items.flag" @click="itemsProduct(item,items)">
              </div>
              <div class="product-img">
                  <img :src="items.url" alt="">
              </div>
              <div class="product-text">
                  <h3 class="text-nowrap">{{items.theme}}</h3>
                  <div>
                      <span class="text-orange">{{items.price}}元</span>
                      <div class="computed">
                          <span class="bdr1" @click="change('-',items)">-</span>
                          <span>{{items.count}}</span>
                          <span class="bdl1" @click="change('+',items)">+</span>
                      </div>
                  </div>
              </div>
          </div>
      </div>
      {{data}}
  </div>
</template>

<script>
export default {
    props:['data'],
    created(){
        this.Quanxuan();
    },
    methods:{
        Quanxuan(){
            this.data.map((item)=>{
                this.$bus.on('all',(val)=>{
                    if(val=='ok'){
                        item.flag=true;
                        item.value.map((items)=>{
                            items.flag=true;
                        })
                    }else{
                        item.flag=false;
                        item.value.map((items)=>{
                            items.flag=false;
                        })
                    }
                    this.total();
                })
            })
            
        },
        //点击商铺，商铺里的商品选中
        itemHotel(item){
            item.flag = !item.flag;
            item.value.map((items)=>{
                if(item.flag){
                    items.flag=true;
                }else{
                    items.flag=false;
                }
            })
            this.All();
            this.total();
        },
        //点击商品，全选时，商铺选中
        itemsProduct(item,items){
            items.flag = !items.flag;
            let arr = [];
            item.value.map((val)=>{
                if(val.flag){
                    arr.push(val);
                }
            })
            if(arr.length == item.value.length){
                item.flag=true;
            }else{
                item.flag=false;
            }
            this.All();
            this.total();
        },
        //全选
        All(){
            let itemArr = [];
            this.data.map((item)=>{
                if(item.flag){
                    itemArr.push(item);
                }
            })
            if(itemArr.length == this.data.length){
                this.$bus.emit('CheckAll','ok');
            }else{
                this.$bus.emit('CheckAll','no');
            }
            this.total();
        },
        //店家加减，每一个商品数量改变
        change(val,items){
            if(val == '-'){
                if(items.count<=1){
                    return;
                }
                items.count--;
            }else{
                items.count++;
            }
            this.total();
        },
        //计算数量和价格
        total(){
            let price = 0;
            let count = 0;
            this.data.map((item)=>{
                item.value.map((items)=>{
                    if(items.flag){
                        price+=items.count*items.price;
                        count+=items.count;
                    }
                })
            })
            this.$bus.emit('buna',price,count);
        }
    }
}
</script>

<style>
.shopcar-item{
    padding: .1rem;
    border-bottom:.1rem solid #eee;
}
.shopcar-hotel{
    line-height: .3rem;
}
.shopcar-product{
    display: flex;
}
.product-ins{
    width: 10%;
}
.product-img{
    width: 30%;
}
.product-img img{
    width: 1rem;
    height:auto;
}
.product-text{
    width: 50%;
    padding-left:.1rem;
    line-height: .3rem;
}
.product-text div{
    display: flex;
    justify-content: space-between;
}
.computed{
    display: inline-block;
    border:1px solid #ccc;
}
.computed span{
    width: .3rem;
    text-align: center;
}
</style>
