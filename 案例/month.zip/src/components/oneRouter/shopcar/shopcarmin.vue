<template>
  <div class="shopcarmin">
      <div>
          <input type="checkbox" v-model="allCheck" @click="AllCheck">
          <label>全选</label>
      </div>
      <div>
          <span>总计：{{price}}</span>
          <span class="count">结算（{{count}}）</span>
      </div>
  </div>
</template>

<script>
export default {
    data(){
        return {
            allCheck:false,
            price:0,
            count:0
        }
    },
    mounted(){
        this.$bus.on('CheckAll',(val)=>{
            if(val=='ok'){
                this.allCheck=true;
            }else{
                this.allCheck=false;
            }
        })
        this.$bus.on('buna',(price,count)=>{
            this.price=price.toFixed(2);
            this.count=count;
        })
    },
    methods:{
        AllCheck(){
            this.allCheck = !this.allCheck;
            if(this.allCheck){
                this.$bus.emit('all','ok');
            }else{
                this.$bus.emit('all','no');
            }
        }
    }
}
</script>

<style>
.shopcarmin{
    display: flex;
    justify-content: space-between;
    line-height: .5rem;
}
.count{
    width: .8rem;
    background: orangered;
    display: inline-block;
    color:#fff;
    text-align: center;
    margin-left:.1rem;
}
</style>
