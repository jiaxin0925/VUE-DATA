<template>
  <div class="shopcar-box">
      <shopcar-top class="top" :data="data"></shopcar-top>
      <shopcarmin class="min"></shopcarmin>
  </div>
</template>

<script>
import axios from 'axios';
import shopcarTop from './shopcar/shopcarTop.vue';
import shopcarmin from './shopcar/shopcarmin.vue';
export default {
data(){
  return {
    data:[]
  }
},
components:{
  shopcarTop,
  shopcarmin
},
mounted(){
  axios.get('/shopcar')
  .then((result)=>{
    this.data=result.data;
  })
}
}
</script>

<style>
.shopcar-box{
  position: absolute;
  top:0;
  left:0;
  right:0;
  bottom:0.5rem;
  display: flex;
  flex-direction: column;
}
.top{
  flex:1;
  overflow-y: scroll;
}
.min{
  height: .5rem;
  border-top:.01rem solid #ccc;
}
</style>
