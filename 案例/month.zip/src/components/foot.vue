<template>
  <div class="foot-box">
      <router-link active-class="active" to="home" tag="div">
          首页
      </router-link>
      <router-link active-class="active" to="weitao" tag="div">
          微淘
      </router-link>
      <router-link active-class="active" to="news" tag="div">
          消息
      </router-link>
      <router-link active-class="active" to="shopcar" tag="div">
          购物车
      </router-link>
      <router-link active-class="active" to="mine" tag="div">
          我的
      </router-link>
  </div>
</template>

<script>
export default {

}
</script>

<style>
.foot-box{
    display: flex;
    border-top:1px solid #ccc;
}
.foot-box div{
    flex:1;
    text-align: center;
    line-height: .5rem;
}
.active{
    color:orangered;
}
</style>
