import axios from 'axios';
import adapter from 'axios-mock-adapter';

import shopcar from './shopcar.json';

let mock = new adapter(axios);

mock.onGet('/shopcar').reply(200,shopcar);