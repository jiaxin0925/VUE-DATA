import Vue from 'vue'
import Router from 'vue-router'
import index from '@/components/index'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'index',
      component: index,
      children:[
        {
          path:'/',
          redirect:'/home'
        },
        {
          path:'/home',
          name:'home',
          component:()=>import('../components/oneRouter/home.vue')
        },
        {
          path:'/weitao',
          name:'weitao',
          component:()=>import('../components/oneRouter/weitao.vue')
        },
        {
          path:'/news',
          name:'news',
          component:()=>import('../components/oneRouter/news.vue')
        },
        {
          path:'/shopcar',
          name:'shopcar',
          component:()=>import('../components/oneRouter/shopcar.vue')
        },
        {
          path:'/mine',
          name:'mine',
          component:()=>import('../components/oneRouter/mine.vue')
        }
      ]
    }
  ]
})
